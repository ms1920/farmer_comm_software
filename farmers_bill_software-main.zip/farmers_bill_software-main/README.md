# farmers_bill_software
A platform for communication between farmer and companies
